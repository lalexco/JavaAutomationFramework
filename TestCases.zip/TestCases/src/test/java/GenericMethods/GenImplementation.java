package GenericMethods;

public interface GenImplementation {
	
	void ValidateTitle();
	

}
